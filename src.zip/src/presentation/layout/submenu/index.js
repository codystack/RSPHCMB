// import React from "react";

// const SubMenu = () => {
//   return (
//     <div>
//       <ul className="nav__submenu">
//         <li className="nav__submenu-item ">
//           <a>Our Company</a>
//         </li>
//         <li className="nav__submenu-item ">
//           <a>Our Team</a>
//         </li>
//         <li className="nav__submenu-item ">
//           <a>Our Portfolio</a>
//         </li>
//       </ul>
//     </div>
//   );
// };

// export default SubMenu;
