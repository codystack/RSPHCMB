import React from "react";
import MainNavbar from "./main_navbar";

const MyNavbar = () => {
  return <MainNavbar />;
};

export default MyNavbar;
